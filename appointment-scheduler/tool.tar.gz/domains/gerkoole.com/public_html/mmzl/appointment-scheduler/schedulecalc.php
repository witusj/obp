<?php
error_reporting(0); 
//error_reporting(E_ALL ^ E_NOTICE);
// Process input

if (isset($_POST['beta'])) { $beta = $_POST['beta']; } else { $beta = null; }
//if (isset($_POST['I'])) { $I = $_POST['I']; } else { $I = null; }
if (isset($_POST['d'])) { $d = $_POST['d']; } else { $d = null; }
if (isset($_POST['TotalTime'])) { $TotalTime = $_POST['TotalTime']; } else { $TotalTime = null; }
$I = $TotalTime / $d;
if (isset($_POST['n'])) { $n = $_POST['n']; } else { $n = null; }
if (isset($_POST['mu'])) { $mu = $_POST['mu']; } else { $mu = null; }
if (isset($_POST['no_show'])) { $no_show = $_POST['no_show']; } else { $no_show = null; }
//if (isset($_POST['alpha_W'])) { $alpha_W = $_POST['alpha_W']; } else { $alpha_W = null; }
//if (isset($_POST['alpha_I'])) { $alpha_I = $_POST['alpha_I']; } else { $alpha_I = null; }
$alpha_I = 0;
//if (isset($_POST['alpha_T'])) { $alpha_T = $_POST['alpha_T']; } else { $alpha_T = null; }
if (isset($_POST['alphaSlider'])) { $alphaSlider = $_POST['alphaSlider']; } else { $alphaSlider = null; }
$alpha_T = $alphaSlider/1000 - 0.00000001;
$alpha_W = (1 - $alpha_T) + 0.00000001;
if (isset($_POST['column1'])) { $column1 = $_POST['column1']; } else { $column1 = null; }
if (isset($_POST['column3'])) { $column3 = $_POST['column3']; } else { $column3 = null; }
if (isset($_POST['model'])) { $model = $_POST['model']; } else { $model = null; }

$x_zelf = null;
?>

<style>
.slidecontainer {
    width: 100%;
}

.slider {
    -webkit-appearance: none;
    width: 100%;
    height: 10px;
    background: #d3d3d3;
    outline: none;
    opacity: 0.7;
    -webkit-transition: .2s;
    transition: opacity .2s;
}

.slider:hover {
    opacity: 1;
}

.slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 20px;
    height: 20px;
    background: #4CAF50;
    cursor: pointer;
}

.slider::-moz-range-thumb {
    width: 25px;
    height: 25px;
    background: #4CAF50;
    cursor: pointer;
}
</style>

<script>
	var slider = document.getElementById("myRange");
	var output = document.getElementById("demo");
	output.innerHTML = slider.value;

	slider.oninput = function() {
		output.innerHTML = this.value;
}
</script>

<html>

	<head>

	<TITLE>Optimal outpatient appointment scheduling tool</TITLE>

	<META NAME="description" CONTENT="On this page presents a health-care outpatient appointment scheduling tool">

	<META NAME="keywords" CONTENT="software, health care, optimization, local search, multimodularity, appointment, outpatient, schedule">

	<link rel="stylesheet" href="style.css" type="text/css">
    <script src="amcharts.js" type="text/javascript"></script>
    <script src="serial.js" type="text/javascript"></script>
	
	</head>

	<body bgcolor="#FFFFFF" link="#003399" vlink="#003399" alink="#003399">
		<center>

		<form action="schedulecalc.php" name="formulier" method=post>

		<table border=0 bgcolor=#FFFFFF>

		<tr>

			<td width=200></td>

			<td width=200></td>

			<td width=180></td>

			<td width=180></td>

		</tr>

		<tr>

			<td colspan=3 bgcolor="#FFFFFF" align=left><font color="#000000"><b>Optimal outpatient appointment scheduling tool</b></font></td>
			<td bgcolor="#FFFFFF" align=right><span title="Click on this questionmark to go to the help page."><A HREF="help.html"><img width=25 height=25 src="questionmark.png"></A></td>

		</tr>
		<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Input</b><td>
		</tr>

	<tr> <td colspan = 4>
	<FIELDSET><table border = 0>
	
	<tr>

		<td width = 250>Total number of arrivals</td>
		<td width = 250>  <input type=text name="n" value="<?php print("$n") ?>" size=6></td>
		<td width = 180></td>
		<td width = 180 rowspan=7><b><input type=submit name="submit" value="Compute the solutions"></b>
		<p><div id="progress"></div></p>
		</td>

	</tr>
	
	<tr>

		<td width = 250>Average service time</td>

		<td width = 250> <input type=text name="beta" value="<?php print("$beta") ?>" size=6> minutes</td>

		<td width = 180></td>

	</tr>

	<!--<tr>

		<td>Number of intervals</td>

		<td> <input type=text name="I" value="<?php print("$I") ?>" size=6> </td>

		<td></td>

	</tr>-->
	
	<tr>

		<td>Total available time</td>

		<td> <input type=text name="TotalTime" value="<?php print("$TotalTime") ?>" size=6> minutes </td>

		<td></td>

	</tr>

	<tr>

		<td>Schedule in intervals of</td>

		<td> <input type=text name="d" value="<?php print("$d") ?>" size=6> minutes

		</td><td></td>

	</tr>

	<tr>

		<td>Percentage no-shows</td>

		<td>  <input type=text name="no_show" value="<?php print("$no_show") ?>" size=6> %

		</td><td></td>

	</tr>
	<tr>
		<td>Patient-centric</td>
		<td>
			<div class="slidecontainer">
			<input type="range" min="0" max="1000" value="<?php print("$alphaSlider") ?>" class="slider" id="myRange" name = "alphaSlider">
			</div>
		</td>
		<td align=right>Doctor-centric</td>
	</tr>
	</table></FIELDSET>
	</tr>

		<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Options for results</b><td>
		</tr>

	<tr><td colspan = 4>
	<FIELDSET><table border = 0>
	<colgroup>
        <col width="5%">
        <col width="5%">
        <col width="90%">
    </colgroup>
	<tr>
		<?php //uitprinten output

			if($column1==TRUE){

		?>

			<td align="right"><input type="checkbox" name="column1" checked></td>

		<?php

			}else{

		?>

			<td align="right"><input type="checkbox" name="column1"></td>
		
		<?php
			}
		?>
		<td colspan="2">Results of the average number of patients</td>
	</tr>
	<tr>
		<?php //uitprinten output

			if($column3==TRUE){

		?>

			<td align="right"><input type="checkbox" name="column3" checked></td>

		<?php

			}else{

		?>

			<td align="right"><input type="checkbox" name="column3"></td>
		
		<?php
			}
		?>
		<td colspan="2">Results of the Small or Full Neighborhood</td>
	</tr>
	<tr>
		<td></td>
		<?php //uitprinten output

			if($model=="SMALL"){

		?>

			<td align="right"><input type="radio" value="SMALL" name="model" checked></td>

		<?php

			}else{

		?>

			<td align="right"><input type="radio" value="SMALL" name="model"></td>
		
		<?php
			}
		?>
		<td>Small Neighborhood <br><i> (Suboptimal, short calculation time)</i></td>
	</tr>
	<tr>
		<td></td>
		<?php //uitprinten output

			if($model=="FULL"){

		?>

			<td align="right"><input type="radio" value="FULL" name="model" checked></td>

		<?php

			}else{

		?>

			<td align="right"><input type="radio" value="FULL" name="model"></td>
		
		<?php
			}
		?>
		<td>Full Neighborhood <br><i> (Optimal, long calculation time)</i></td>
	</tr>
	</table></FIELDSET>
	</tr>


<?php
/*	$floor = floor($n / $I);
	$ceil = ceil($n / $I);
	if ($n <= $I){
		if($n == $I){
			for($interval=1; $interval<=$I; $interval++){
				$x_zelf[$interval] = 1;
			}
		} else{
			for($interval=1; $interval<=$n; $interval++){
				$x_zelf[$interval] = 1;
			}
			for($interval=$n+1; $interval<=$I; $interval++){
				$x_zelf[$interval] = 0;
			}
		}
	} else {
		if($n % $I == 0){
			for($interval=1; $interval<=$I; $interval++){
				$x_zelf[$interval] = $ceil;
			}
		} else {
			$remainder = $n;
			$counter = $I + 1;
			$boolean = false;
			for($interval=1; $interval<=$I; $interval++){
				if($boolean){
					$x_zelf[$interval] = $floor;
				} else {
					$x_zelf[$interval] = $ceil;
				}
				if($interval * $ceil + ($I - $interval) * $floor == $n){
					$boolean = true;
				}
			}
		}
	}*/
	for($interval=1; $interval<=$I; $interval++){
		$x_zelf[$interval] = 0;
	}
	for($patient=1; $patient<=$n; $patient++){
		/*$interval = round($patient * $I / $n);
		if($interval == 0){
			$interval += 1;
		}*/
		$interval = round(($patient-1)*$I / $n)+1;
		if($interval > $I){
			$interval -= 1;
		}
		$x_zelf[$interval] += 1;
	}
	
?>
		<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Number of arrivals per time interval</b></td>
		</tr>
		<tr>
			<td colspan = 4><div id="chartdiv" style="width: 100%; height: 400px;"></div></td>
		</tr>
		<tr>
			<td colspan=4 bgcolor="#FFFFFF"><b>Output</b></td>
		</tr>
		<tr><td colspan = 4>
		<FIELDSET><table border = 0>
		<colgroup>
			<col width=100>
			<col width=100>
			<col width=200>
			<col width=300>
		</colgroup>
		<tr>
			<td colspan=2></td>
			<td>Individual schedule</td>
			<td>Optimized schedule</td>
		</tr>
		<tr>

			<td colspan=2>Waiting time<br></td>

			<td><input type=text name="waitingTime_zelf" size=6 disabled> minutes</td>

			<td><input type=text name="waitingTime" size=6 disabled> minutes</td>

		</tr>

		<tr>

			<td colspan=2>Idle time<br></td>

			<td><input type=text name="idleTime_zelf" size=6 disabled> minutes</td>

			<td><input type=text name="idleTime" size=6 disabled>

			minutes</td>

		</tr>

		<tr>

			<td colspan=2>Tardiness<br></td>

			<td><input type=text name="tardiness_zelf" size=6 disabled> minutes</td>

			<td><input type=text name="tardiness" size=6 disabled>

			minutes</td>

		</tr>

		<tr>

			<td colspan=2>Fraction of excess<br></td>

			<td><input type=text name="fracExcess_zelf" size=6 disabled> %</td>

			<td><input type=text name="fracExcess" size=6 disabled> %</td>

		</tr>

		<tr>

			<td><br></td>

		</tr>

		<tr>

			<td colspan=2>Makespan<br></td>

			<td><input type=text name="makeSpan_zelf" size=6 disabled> minutes</td>

			<td><input type=text name="makeSpan" size=6 disabled> minutes</td>

		</tr>

		<tr>

			<td colspan=2>Lateness<br></td>

			<td><input type=text name="lateness_zelf" size=6 disabled> minutes</td>

			<td><input type=text name="lateness" size=6 disabled> minutes</td>

		</tr>

		<tr>

			<td><br></td>

		</tr>

		<tr>

			<td colspan=2>Objective Value<br></td>

			<td><input type=text name="objVal_zelf" size=6 disabled></td>

			<td><input type=text name="objVal" size=6 disabled>

			</td>

		</tr>
		</table></FIELDSET>
		</tr>

		</table>
		

		<br>

		<TABLE WIDTH=100%>

		<TR>

			<TD WIDTH=20% ALIGN=left>

				<A HREF="disclaimer.html">disclaimer</A>

			</TD>

			<TD WIDTH=50% ALIGN=center>
&copy; 2007-2018
Guido Kaandorp,
<A HREF="http://www.few.vu.nl/~koole">Ger Koole</A> and Jerry Timmer (thanks to Dennis Roubos)
			</TD>

			<TD WIDTH=30% ALIGN=right>

				 <!--<A HREF="help.html">help</A>

				 | --><A HREF="mailto: koole@few.vu.nl">contact</A>

			</TD>

		</tr>

		</TABLE>

		</form>

		</center>


</body>

</html>

<?php



flush();

set_time_limit(0);



//p EN a BEPALEN

$p_no_show = $no_show/100;

$i=0;

$p=array();

$a=array();

$p[$i]=p($i,$mu,$d);

$a[$i]=1;

while(0.0000000000000001 < $p[$i] ){

   $i++;

   $p[$i]=p($i);

   $a[$i]=a($i); 

//   print("i");print($i);print(" a");print(a($i));print(" p");print(p($i));print("<br>");

}


//OPLOSSING BEPALEN VAN COLUMN 1 (EIGEN ROOSTER)

if($column1==TRUE) {
	echo "<script>document.getElementById('progress').innerHTML = \"Calculating individual schedule...\";</script>"; flush();
	
    $n_temp =$n;

	$n=0;

	$x_plek=array();

	$n+=$x_zelf[1];

	$aantal=0;

	if ($x_zelf[1]>1){

	   $aantal++;

	   $x_plek[$aantal]=1;

	}

	for($interval=2; $interval<=$I; $interval++){

		$n+=$x_zelf[$interval];

		if ($x_zelf[$interval]>0){

	   	   $aantal++;

	   	   $x_plek[$aantal]=$interval;

		}

	}

	$x_zelf[1]-=1;

	

  $results=results($x_zelf, 1);

	$waitingTime_zelf = round($results['waitingTime'],2);

  $idleTime_zelf = round($results['idleTime'],2);

  $tardiness_zelf = round($results['tardiness'],2);

	$objVal_zelf = round($results['objVal'],2);

	$fracExcess_zelf = round($results['fracExcess'],2);

	$makeSpan_zelf = $idleTime_zelf+$beta*$n*(1-$p_no_show);

	$lateness_zelf = $makeSpan_zelf-$d*$I;

  $n =$n_temp;

?>

<script>
	eval("document.formulier.waitingTime_zelf.value = " + <?php print("$waitingTime_zelf") ?>);
	eval("document.formulier.idleTime_zelf.value = " + <?php print("$idleTime_zelf") ?>);
	eval("document.formulier.tardiness_zelf.value = " + <?php print("$tardiness_zelf") ?>);
	eval("document.formulier.fracExcess_zelf.value = " + <?php print("$fracExcess_zelf") ?>);
	eval("document.formulier.makeSpan_zelf.value = " + <?php print("$makeSpan_zelf") ?>);
	eval("document.formulier.lateness_zelf.value = " + <?php print("$lateness_zelf") ?>);
	eval("document.formulier.objVal_zelf.value = " + <?php print("$objVal_zelf") ?>);
</script>
<?php
echo "<script>document.getElementById('progress').innerHTML = \"Finished calculating individual schedule.\";</script>"; flush();
	
}//end if


//OPLOSSING BEPALEN

if($column3==TRUE) {

  //STARTWAARDEN x
  $x[1]=$n-1; // why do we need $n -1 ????? 1 always stays at 1
  for($interval=2;$interval<=$I;$interval++) $x[$interval]=0;
  $results=results($x, 0);
	?>
	<?php
	for($interval=2; $interval<=$I; $interval++){
		?>
		<?php
	}
	?>
	<script>
	   eval("document.formulier.waitingTime.value = " + <?php print("$results[waitingTime]") ?>);
	   eval("document.formulier.idleTime.value = " + <?php print("$results[idleTime]") ?>);
	   eval("document.formulier.tardiness.value = " + <?php print("$results[tardiness]") ?>);
	   eval("document.formulier.objVal.value = " + <?php print("$results[objVal]") ?>);
	</script>
	<?php
	//flush();
	if ($model=="SMALL"){
		$counter_progress = 0;
  	   echo "<script>document.getElementById('progress').innerHTML = \"Searching small neighborhood...\";</script>"; flush();
	
	   do{
	      $counter_progress++;
	      list ($x,$results) = iteratie_small($x,$results);
	      if ($counter_progress % 10 == 0) {
			echo "<script>document.getElementById('progress').innerHTML = \"Searching small neighborhood...<br>Performed $counter_progress iterations.\";</script>"; flush();
		}
        }while($results != "");
        echo "<script>document.getElementById('progress').innerHTML = \"Finished searching small neighborhood.\";</script>"; flush();
	}else if($model=="FULL"){
		echo "<script>document.getElementById('progress').innerHTML = \"Searching full neighborhood...\";</script>"; flush();
	
        do{
	      list ($x,$results) = iteratie_small($x,$results);
           }while($results != "");
           do{
	      list ($x,$results) = iteratie_full($x,$results);
	   }while($results != ""); 
	   echo "<script>document.getElementById('progress').innerHTML = \"Finished searching full neighborhood.\";</script>"; flush();
	
	}
	$results=results($x, 1);
	$waitingTime = round($results['waitingTime'],2);
  $idleTime = round($results['idleTime'],2);
  $tardiness = round($results['tardiness'],2);
	$objVal = round($results['objVal'],2);
	$fracExcess = round($results['fracExcess'],2);
	$makeSpan = $idleTime+$beta*$n*(1-$p_no_show);
	$lateness = $makeSpan-$d*$I;
//print($makeSpan);print("<br>");
//print($lateness);print("<br>");
	?>
	<?php
	for($interval=2; $interval<=$I; $interval++){
		?>
		<?php
	}
	?>
	<script>
		eval("document.formulier.waitingTime.value = " + <?php print("$waitingTime") ?>);
		eval("document.formulier.idleTime.value = " + <?php print("$idleTime") ?>);
		eval("document.formulier.tardiness.value = " + <?php print("$tardiness") ?>);
		eval("document.formulier.fracExcess.value = " + <?php print("$fracExcess") ?>);
		eval("document.formulier.makeSpan.value = " + <?php print("$makeSpan") ?>);
		eval("document.formulier.lateness.value = " + <?php print("$lateness") ?>);
		eval("document.formulier.objVal.value = " + <?php print("$objVal") ?>);
	</script>
	<?php
	echo "<script>document.getElementById('progress').innerHTML = \"Finished searching.\";</script>"; flush();

} //END IF


//ITERATIE SMALL

function iteratie_small($x,$results){
	global $I;
        // we are going to shift from k to (k+m-1 mod I)  (m further)
	for($m=1; $m<$I; $m++)for($k=$I; $k>0; $k--)if($x[$k]>0){
             for($interval=1; $interval<=$I; $interval++)$x_temp[$interval]=$x[$interval];
	     $x_temp[$k]-=1;
             $x_temp[(($k+$m-1) % $I)+1]+=1;	   
	     $results_temp=results($x_temp, 0);
	     if($results_temp['objVal']<$results['objVal']) {
					?>
					<?php
					for($interval=2; $interval<=$I; $interval++){
						?>
						<?php
					} // endfor
					?>
					<script>
eval("document.formulier.waitingTime.value = " + <?php print("$results_temp[waitingTime]") ?>);
eval("document.formulier.idleTime.value = " + <?php print("$results_temp[idleTime]") ?>);
eval("document.formulier.tardiness.value = " + <?php print("$results_temp[tardiness]") ?>);
eval("document.formulier.objVal.value = " + <?php print("$results[objVal]") ?>);
					</script>
					<?php
					//flush();
					return array ($x_temp, $results_temp);
	     } // endif
	} // endforif
	return array ($x, "");
} // end iteratie_small


//PROBABILITIES FUNCTION + W(x), I(x), T(x)

function calculateProbabilities($x){

	global $I;
	global $n;
	global $p;
	global $a;
	global $d;
	global $beta;

	global $p_no_show;



	$waiting=0;

	$makespan=0;

	$tardiness=0;

	//interval 1

	$n_tot=$x[1];

  $p_min[1][0]=1;

	for ($i=0;$i<=$n_tot;$i++){

		$p_plus[1][$i]=boven($x[1],$i)*pow($p_no_show,($x[1]-$i))*pow((1-$p_no_show),$i);

//print("t: 1");print(" j: ");print($i);print("  kans: ");print($p_plus[1][(integer)$i]);print("<br>");

	}

	//waiting

	$t=1;

	if ($p_no_show==0){

	    for($i=1; $i<=$x[$t]; $i++){
    			for ($j=0; $j<=$n; $j++){
    				$waiting += $p_min[$t][$j]*($j-1+$i)*$beta;
    			}
	    }
	}else{
			for($k=1; $k<=$x[$t]; $k++){
				$tempW=0;
    			for($i=1; $i<=$k; $i++){
    				for ($j=0; $j<=$n; $j++){
						if (isset($p_min[$t][$j])) {
    						$tempW += $p_min[$t][$j]*($j-1+$i)*$beta;
    					}
    				}
    			}
				$tempW*=boven($x[$t],$k)*pow($p_no_show,($x[$t]-$k))*pow((1-$p_no_show),$k);
				$waiting+=$tempW;
			}
	}
	//make span
	$tempM=$n;
	if($x[$t]>0){
		$tempM -= $x[$t];
		$makespan_temp = 0;
		for($k=1; $k<=$x[$t]; $k++){
			 $makespan_temp2 = 0;
			 for ($i=0;$i<=$n_tot;$i++){
				if (isset($p_min[$t][$i])) {
					$makespan_temp2 += $p_min[$t][$i]*($i+$k)*$beta;
				}
			 }
			 $makespan_temp+=boven(($x[$t]),$k)*pow($p_no_show,$x[$t]-$k)*pow(1-$p_no_show,$k)/(1-pow($p_no_show,$x[$t]))*$makespan_temp2;
		}
		//$makespan_temp+=($t-1)*$d;
		$makespan += pow($p_no_show,$tempM) * (1-pow($p_no_show,$x[$t])) * $makespan_temp;
	}

// intervallen groter dan 1:
//print("<br>");
	
    for ($t=2; $t<=$I+1; $t++){
	//p_min(0)
	
		$p_min[$t][0]=0;
    	//kan som x1+x2+... i.p.v. N

		if (!isset($x[$t])) {
			$x[$t] = 0;
		}
		
		$n_tot+=$x[$t];
		
    	for ($i=0; $i<=$n_tot; $i++){
			if (isset($p_plus[(integer)($t-1)][$i])) {
    			$p_min[(integer)$t][0] += $p_plus[(integer)($t-1)][$i]*$a[(integer)$i];
    		}
    	}
		//p_min(j)
    	for ($j=1; $j<=$n; $j++){
    		$p_min[(integer)$t][(integer)$j]=0;
    		for ($i=$j; $i<=$n; $i++){
				if (isset($p_plus[(integer)($t-1)][(integer)$i])) {
					$p_min[(integer)$t][(integer)$j]+=$p_plus[(integer)($t-1)][(integer)$i]*$p[(integer)($i-$j)];
				}
    		}
    	}
		if ($p_no_show == 0){
			//p_plus(j)
	    	for ($j=0; $j<(integer)$x[$t]; $j++){
    			$p_plus[(integer)$t][(integer)$j]=0;
	    	}
			for ($j=$x[$t];$j<=$n;$j++){
    			$p_plus[(integer)$t][(integer)$j]=$p_min[(integer)$t][(integer)($j-$x[$t])];
	    	}
    	}else{
			for ($j=0;$j<=$n;$j++){
				$p_plus[(integer)$t][(integer)$j]=0;
    			for ($i=0; $i<=$x[$t]; $i++){
					if (isset($p_min[(integer)$t][(integer)($j-$i)])) {
						$p_plus[(integer)$t][(integer)$j]+=$p_min[(integer)$t][(integer)($j-$i)]*boven($x[$t],$i)*pow($p_no_show,($x[$t]-$i))*pow((1-$p_no_show),$i);
					}
				}
	    	}
		}
		//waiting
		if ($p_no_show==0){
	    for($i=1; $i<=$x[$t]; $i++){
    			for ($j=0; $j<=$n; $j++){

    				$waiting += $p_min[$t][$j]*($j-1+$i)*$beta;

    			}

	    }

		}else{

				for($k=1; $k<=$x[$t]; $k++){

					$tempW=0;

	    			for($i=1; $i<=$k; $i++){

	    				for ($j=0; $j<=$n; $j++){

	    					$tempW += $p_min[$t][$j]*($j-1+$i)*$beta;

	    				}

	    			}

					$tempW*=boven($x[$t],$k)*pow($p_no_show,($x[$t]-$k))*pow((1-$p_no_show),$k);

					$waiting+=$tempW;

		    }

		}



		//make span

		if($x[$t]>0){

			$tempM -= $x[$t];

			$makespan_temp = 0;

			for($k=1; $k<=$x[$t]; $k++){

				 $makespan_temp2 = 0;

				 for ($i=0;$i<=$n_tot;$i++){

				 	  $makespan_temp2 += $p_min[$t][$i]*($i+$k)*$beta;

				 }

				 $makespan_temp+=boven(($x[$t]),$k)*pow($p_no_show,$x[$t]-$k)*pow(1-$p_no_show,$k)/(1-pow($p_no_show,$x[$t]))*$makespan_temp2;

			}

			$makespan_temp+=($t-1)*$d;
			$makespan += pow($p_no_show,$tempM) * (1-pow($p_no_show,$x[$t])) * $makespan_temp;

	 }

	}





	

	if ($p_no_show==1){

		 $waiting=0;

	}else{

  	$waiting/=($n*(1-$p_no_show));

  }

		

//tardiness

	for ($j=1; $j<=$n; $j++){

		$tardiness += $p_min[$I+1][$j]*$j*$beta;

	}



	$idletime=$makespan-$n*(1-$p_no_show)*$beta;

	return array ($p_min, $p_plus, $waiting, $idletime ,$tardiness);

}







//p FUNCTIE

function p($i) {

	global $beta;

	global $d;

	$mu=1/$beta;

	if($i>20){ //dan werkt fact niet meer (java)

		$resultaat = 1;

		for ($j=1; $j<=$i; $j++){

			$resultaat*=$d*$mu/$j;

			}

		return $resultaat * exp(-$mu * $d);

	}

    return pow(($mu * $d),$i) / fact($i) * exp(-$mu * $d);

}



function fact($i){

    if ($i==0){

		return 1;

	}

	return $i*fact($i-1);

}



function boven($k, $i){

	return fact($k)/(fact($k-$i)*fact($i));

}



function som($i){

	if ($i==1){

		return 1;

	}

	return $i+som($i-1);

}



//a FUNCTIE

function a($i){

    global $p;

    $help = 1;

    if ($i == 0){

        return $help;

    } else {

        for ($j = 0; $j< $i; $j++){

        	$help = $help - $p[$j];

    	}

        return $help;

	}

}



//BEREKEN WAITING, IDLE TIME, TARDINESS EN OBJECTIVEVALUE VOOR GEGEVEN SCHEDULE

function results($schedule, $eind){

	global $alpha_W;

	global $alpha_I;

	global $alpha_T;

	$p_min = array();

	$p_plus = array();

	$schedule[1]+=1;

	

	list ($p_min, $p_plus, $results['waitingTime'], $results['idleTime'], $results['tardiness']) = calculateProbabilities($schedule);

	$results['objVal'] = $alpha_W*$results['waitingTime']+$alpha_I*$results['idleTime']+$alpha_T*$results['tardiness'];

	if($eind==1){

		$results['fracExcess'] = calculateFracExcess($p_min);

	}

	return $results;

}



function calculateFracExcess($p_min){

	global $I;

	global $n;

	$fracExcess=0;

	$t=$I+1;

	for($j=1; $j<=$n; $j++){

   		$fracExcess+=$p_min[$t][$j];

   	}

	$fracExcess*=100;

	return $fracExcess;

}


//ITERATIE FULL

function iteratie_full($x,$results){

	global $I;
        // initialization 
        // x_pos_indices contains indices of positive entries of x 
        // num_pos_entries the number of positive entries
	$num_pos_entries=0;   
        for($k=1;$k<=$I;$k++)if($x[$k]>0)$x_pos_indices[++$num_pos_entries]=$k;
        // x_dist_next_one is number of positions until next entry >0
        for($k=1;$k<$num_pos_entries;$k++)
              $x_dist_next_one[$k]=$x_pos_indices[$k+1]-$x_pos_indices[$k];
        $x_dist_next_one[$num_pos_entries]=$I-$x_pos_indices[$num_pos_entries]+$x_pos_indices[1];
        // maxiter is number of possible schedules --- iter shows current iteration
        $maxiter=1;
        for($k=1;$k<=$num_pos_entries;$k++){$maxiter*=$x_dist_next_one[$k]+1;$iter[$k]=0;}
        // iterate
	for($iter_num=1; $iter_num<=$maxiter; $iter_num++){
	     // iter[k] will contain the number of intervals that a patient at the k-th positive
             // interval will be shifted forward --- maximum is x_dist_next_one[k]
	     $iter[1]++;
             if($iter[1]==$x_dist_next_one[1]+1) // extra condition to speed up code
               for($k=1;$k<=$num_pos_entries;$k++)      
                 if($iter[$k]==$x_dist_next_one[$k]+1){$iter[$k]=0;$iter[$k+1]++;}
             // determine new schedule x_temp
             for($k=1;$k<=$I;$k++)$x_temp[$k]=$x[$k];
             for($k=1;$k<$num_pos_entries;$k++)
	       {$x_temp[$x_pos_indices[$k]]--;$x_temp[$x_pos_indices[$k]+$iter[$k]]++;}
             // special treatment last positive entry because it goes to beginning schedule
             $x_temp[$x_pos_indices[$num_pos_entries]]--;
             $x_temp[($x_pos_indices[$num_pos_entries]+$iter[$num_pos_entries]-1)%$I+1]++;
             
             // print progress
	     if($iter_num%10==0) {
   	        echo "<script>document.getElementById('progress').innerHTML = \"Searching full neighborhood...<br>Checked $iter_num of $maxiter schedules.\";</script>"; flush();
	     }
             $results_temp=results($x_temp, 0);
	     if($results_temp[objVal]<$results[objVal]) {
					?>
					<?php
					for($interval=2; $interval<=$I; $interval++){
						?>
						<?php
					} // endfor
					?>
					<script>
eval("document.formulier.waitingTime.value = " + <?php print("$results_temp[waitingTime]") ?>);
eval("document.formulier.idleTime.value = " + <?php print("$results_temp[idleTime]") ?>);
eval("document.formulier.tardiness.value = " + <?php print("$results_temp[tardiness]") ?>);
eval("document.formulier.objVal.value = " + <?php print("$results[objVal]") ?>);
					</script>
					<?php
					//flush();
					return array ($x_temp, $results_temp);
	     } // endif(improvement)
	} // endfor
	return array ($x, "");
} // end iteratie_full

//ITERATIE FULL BACKUP

function iteratie_full_backup($x,$results){

	global $I;
        $maxiter=pow(2,$I)-1;
        for($k=2;$k<=$I+1;$k++)$pow[$k]=pow(2,$k);
        // the binary representation of i tells which vectors are chosen
	for($i=1; $i<=$maxiter; $i++){
             for($interval=1; $interval<=$I; $interval++)$x_temp[$interval]=$x[$interval];
             // i%2=1 means odd means vector 1 is included
             if($i%2==1){$x_temp[1]-=1;$x_temp[$I]+=1;}
             // for all other vectors look if 2^k is in i; if yes add vector
	     for($k=2;$k<=$I;$k++)if($i % $pow[$k+1] > $pow[$k]-1){$x_temp[$k-1]+=1;$x_temp[$k]-=1;}
             $positief=1;
             for($k=2;$k<=$I;$k++)if($x_temp[$k]<0)$positief=0;
             // print progress
	     if($i%10==0) {
   	        echo "<script>document.getElementById('progress').innerHTML = \"Searching full neighborhood...<br>Checked $i of $maxiter schedules.\";</script>"; flush();
	     }
	     if($positief){
                $results_temp=results($x_temp, 0);
	        if($results_temp[objVal]<$results[objVal]) {
					?>
					<?php
					for($interval=2; $interval<=$I; $interval++){
						?>
						<?php
					} // endfor
					?>
					<script>
eval("document.formulier.waitingTime.value = " + <?php print("$results_temp[waitingTime]") ?>);
eval("document.formulier.idleTime.value = " + <?php print("$results_temp[idleTime]") ?>);
eval("document.formulier.tardiness.value = " + <?php print("$results_temp[tardiness]") ?>);
eval("document.formulier.objVal.value = " + <?php print("$results[objVal]") ?>);
					</script>
					<?php
					//flush();
					return array ($x_temp, $results_temp);
	       } // endif
	     } // endif
	} // endforif
	return array ($x, "");
} // end iteratie_full_backup




?>
<script>
	var averageArray = [];
	var optionArray = [];
	averageArray.push(<?php print("($x_zelf[1]+1)") ?>);
	optionArray.push(<?php print("($x[1]+1)") ?>);
</script>

<?php
	for($interval=2; $interval<=$I; $interval++){
		?>
		<script>
		averageArray.push(<?php print("$x_zelf[$interval]") ?>);
		</script>
		<?php
	}
	?>

<?php
	for($interval2=2; $interval2<=$I; $interval2++){
		?>
		<script>
		optionArray.push(<?php print("$x[$interval2]") ?>);
		</script>
		<?php
	}
	?>
	
<?php
	$minYValue = min(array_slice($x_zelf, 0, $I-1, true));
	if($column3){
		$minX = min(array_slice($x, 0, $I-1, true));
		$minYValue = min($minX, $minYValue);
	}
?>

<script>
	var timeInterval = [];
	
	for(interval = 1; interval <= <?php echo $I; ?>; interval++){
			var minuut=((interval-1)*<?php echo $d; ?>)%60;

			var uur=((interval-1)*<?php echo $d; ?>-minuut)/60;

			uur = uur.toString();
			
			var part1 = uur.concat(":");
			
			if(minuut<10){
				var part1 = part1.concat("0");
			}
			minuut = minuut.toString();
			var part1 = part1.concat(minuut);
			timeInterval.push(part1)
	}		
	

    var chart;
    var chartData = [];
	
	var nameAverage = null;
	
	if (<?php echo json_encode($column1); ?>){
		nameAverage = "Individual schedule"
	} else {
		nameAverage = "Not available"
	}
	
	var nameOption = null;
	
	if (<?php echo json_encode($column3); ?>){
		if (<?php echo json_encode($model); ?>=="SMALL"){
			nameOption = "Small Neighborhood"
		} else if (<?php echo json_encode($model); ?>=="FULL"){
			nameOption = "Full Neighborhood"
		} 
	} else {
			nameOption = "Not available"
	}
	
	if (<?php echo json_encode($column3); ?>){
		for (i = 0; i < <?php echo $I; ?>; i++) { 
				chartData.push({
                    "Time": timeInterval[i],
                    "Option": optionArray[i],
					"Average" : averageArray[i]
                });
			}
	} else {
		for (i = 0; i < <?php echo $I; ?>; i++) { 
				chartData.push({
                    "Time": timeInterval[i],
                    "Option": 0,
					"Average" : averageArray[i]
                });
			}
	}
               
    AmCharts.ready(function () {
        // SERIAL CHART
        chart = new AmCharts.AmSerialChart();
        chart.dataProvider = chartData;
        chart.categoryField = "Time";
        chart.startDuration = 1;

        // AXES
        // category
        var categoryAxis = chart.categoryAxis;
        categoryAxis.labelRotation = 90;
        categoryAxis.gridPosition = "start";
		categoryAxis.title = "Time interval";

        // value
		var valueAxis = new AmCharts.ValueAxis();
		valueAxis.title = "Number of arrivals";
		valueAxis.integersOnly = true;
		valueAxis.minimum = <?php echo json_encode($minYValue); ?>;
		chart.addValueAxis(valueAxis);

		// GRAPH
		var graph = new AmCharts.AmGraph();
		graph.title = nameOption;
        graph.valueField = "Option";
        graph.balloonText = "[[category]]: <b>[[value]]</b>";
		graph.showBalloon = false;
        graph.type = "column";
		graph.lineColor = "#4CAF50";
        graph.lineAlpha = 0;
        graph.fillAlphas = 0.8;
        chart.addGraph(graph);
		
		var graph2 = new AmCharts.AmGraph();
		graph2.title = nameAverage;
        graph2.type = "step"; // this line makes the graph smoothed line.
        graph2.lineColor = "#FF0000";
        graph2.lineThickness = 2;
        graph2.valueField = "Average";
        graph2.balloonText = "[[category]]<br><b><span style='font-size:14px;'>[[value]]</span></b>";
		graph2.showBalloon = false;
        chart.addGraph(graph2);
			
		var legend = new AmCharts.AmLegend();
        legend.borderAlpha = 0.2;
        legend.horizontalGap = 10;
        legend.autoMargins = false;
        legend.marginLeft = 20;
        legend.marginRight = 20;
        chart.addLegend(legend);

        // CURSOR
		var chartCursor = new AmCharts.ChartCursor();
		chartCursor.cursorAlpha = 0;
		chartCursor.zoomable = false;
		chartCursor.categoryBalloonEnabled = true;
		chart.addChartCursor(chartCursor);

		chart.creditsPosition = "top-right";

		chart.write("chartdiv");
	});
</script>