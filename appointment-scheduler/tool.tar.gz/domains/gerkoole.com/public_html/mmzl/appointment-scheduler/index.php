<style>
.slidecontainer {
    width: 100%;
}

.slider {
    -webkit-appearance: none;
    width: 100%;
    height: 10px;
    background: #d3d3d3;
    outline: none;
    opacity: 0.7;
    -webkit-transition: .2s;
    transition: opacity .2s;
}

.slider:hover {
    opacity: 1;
}

.slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 20px;
    height: 20px;
    background: #4CAF50;
    cursor: pointer;
}

.slider::-moz-range-thumb {
    width: 25px;
    height: 25px;
    background: #4CAF50;
    cursor: pointer;
}
</style>

<script>
	var slider = document.getElementById("myRange");
	var output = document.getElementById("demo");
	output.innerHTML = slider.value;

	slider.oninput = function() {
		output.innerHTML = this.value;
}
</script>

<html>
	<head>
	<TITLE>Optimal outpatient appointment scheduling tool</TITLE>
	<META NAME="description" CONTENT="On this page presents a health-care outpatient appointment scheduling tool">
	<META NAME="keywords" CONTENT="software, health care, optimization, local search, multimodularity, appointment, outpatient, schedule">
	<link rel="stylesheet" href="style.css" type="text/css">
    <script src="amcharts.js" type="text/javascript"></script>
    <script src="serial.js" type="text/javascript"></script>
	</head>
	
	<script>
            var chart;

            var chartData = [
                {
                    "Time": "00:00",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "00:30",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "01:00",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "01:30",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "02:00",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "02:30",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "03:00",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "03:30",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "04:00",
                    "Option": 0,
					"Average" : 0
                },
                {
                    "Time": "04:30",
                    "Option": 0,
					"Average" : 0
                },
            ];


            AmCharts.ready(function () {
                // SERIAL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "Time";
                chart.startDuration = 1;

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.labelRotation = 90;
                categoryAxis.gridPosition = "start";
				categoryAxis.title = "Time interval";

                // value
				var valueAxis = new AmCharts.ValueAxis();
				valueAxis.title = "Number of arrivals";
				valueAxis.integersOnly = true;
				chart.addValueAxis(valueAxis);

                // GRAPH
                var graph = new AmCharts.AmGraph();
				graph.title = "Not available";
                graph.valueField = "Option";
                graph.balloonText = "[[category]]: <b>[[value]]</b>";
				graph.showBalloon = false;
                graph.type = "column";
				graph.lineColor = "#4CAF50";
                graph.lineAlpha = 0;
                graph.fillAlphas = 0.8;
                chart.addGraph(graph);
				
				var graph2 = new AmCharts.AmGraph();
				graph2.title = "Not available";
                graph2.type = "smoothedLine"; // this line makes the graph smoothed line.
                graph2.lineColor = "#d1655d";
                graph2.lineThickness = 2;
                graph2.valueField = "Average";
                graph2.balloonText = "[[category]]<br><b><span style='font-size:14px;'>[[value]]</span></b>";
				graph2.showBalloon = false;
                chart.addGraph(graph2);
				
				var legend = new AmCharts.AmLegend();
                legend.borderAlpha = 0.2;
                legend.horizontalGap = 10;
                legend.autoMargins = false;
                legend.marginLeft = 20;
                legend.marginRight = 20;
                chart.addLegend(legend);

                // CURSOR
                var chartCursor = new AmCharts.ChartCursor();
                chartCursor.cursorAlpha = 0;
                chartCursor.zoomable = false;
                chartCursor.categoryBalloonEnabled = true;
                chart.addChartCursor(chartCursor);

                chart.creditsPosition = "top-right";

                chart.write("chartdiv");
            });
        </script>

	<body bgcolor="#FFFFFF" link="#003399" vlink="#003399" alink="#003399">
		<center>
		<form action="schedulecalc.php" name="formulier" method=POST>
		<table border=0 bgcolor=#FFFFFF>
		<tr>
			<td width=200></td>
			<td width=200></td>
			<td width=180></td>
			<td width=180></td>
		</tr>
		<tr>
			<td colspan=3 bgcolor="#FFFFFF" align=left><font color="#000000"><b>Optimal outpatient appointment scheduling tool</b></font></td>
			<td bgcolor="#FFFFFF" align=right><span title="Click on this questionmark to go to the help page."><A HREF="help.html"><img width=25 height=25 src="questionmark.png"></A></td>
		</tr>
		<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Input</b><td>
		</tr>
	<tr> <td colspan = 4>
	<FIELDSET><table border = 0>
	<tr>
		<td width = 250>Total number of arrivals</td>
		<td width = 250>  <input type=text name="n" value=10 size=6></td>
		<td width = 180></td>
		<td width = 180 rowspan=7><b><input type=submit name="submit" value="Compute the solutions"></b>
	</tr>
	<tr>
		<td width = 250>Average service time</td>
		<td width = 250> <input type=text name="beta" value=25 size=6> minutes</td>
		<td width = 180></td>
	</td>
	</tr>
	<!--
	<tr>
		<td>Number of intervals</td>
		<td> <input type=text name="I" value=10 size=6> </td>
		<td></td>
	</tr>
	-->
	<tr>
		<td>Total available time</td>
		<td> <input type=text name="TotalTime" value=300 size=6> minutes
		</td><td></td>
	</tr>
	<tr>
		<td>Schedule in intervals of</td>
		<td> <input type=text name="d" value=30 size=6> minutes
		</td><td></td>
	</tr>
	<tr>
		<td>Percentage no-shows</td>
		<td>  <input type=text name="no_show" value=5 size=6> % 
		</td><td></td>
	</tr>
	<tr>
		<td>Patient-centric</td>
		<td>
			<div class="slidecontainer">
			<input type="range" min="0" max="1000" value="500" class="slider" id="myRange" name = "alphaSlider">
			</div>
		</td>
		<td align=right>Doctor-centric</td>
	</tr>
	</table></FIELDSET>
	</tr>
	<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Options for results</b><td>
	</tr>
	<tr><td colspan = 4>
	<FIELDSET><table border = 0>
	<colgroup>
        <col width="5%">
        <col width="5%">
        <col width="90%">
    </colgroup>
	<tr>
		<td align="right"><input type="checkbox" name="column1" checked></td>
		<td colspan="2">Results of the average number of patients</td>
	</tr>
	<tr>
		<td align="right"><input type="checkbox" name="column3"></td>
		<td colspan="2">Results of the Small or Full Neighborhood</td>
	</tr>
	<tr>
		<td></td>
		<td align="right"><input type="radio" value="SMALL" name="model" checked></td>
		<td>Small Neighborhood <br><i> (Suboptimal, short calculation time)</i></td>
	</tr>
	<tr>
		<td></td>
		<td align="right"><input type="radio" value="FULL" name="model"></td>
		<td>Full Neighborhood <br><i> (Optimal, long calculation time)</i></td>
	</tr>
	</table></FIELDSET>
	</tr>
	<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Number of arrivals per time interval</b></td>
	</tr>
	<tr>
		<td colspan = 4><div id="chartdiv" style="width: 100%; height: 400px;"></div></td>
	</tr>
	<tr>
		<td colspan=4 bgcolor="#FFFFFF"><b>Output</b></td>
	</tr>
	<tr><td colspan = 4>
	<FIELDSET><table border = 0>
	<colgroup>
        <col width=100>
        <col width=100>
        <col width=200>
		<col width=300>
    </colgroup>
	<tr>
			<td colspan=2></td>
			<td>Individual schedule</td>
			<td>Optimized schedule</td>
	</tr>
	<tr>
			<td colspan=2>Waiting time<br></td>
			<td><input type=text name="waitingTime_zelf" size=6 disabled> minutes</td>
			<td><input type=text name="waitingTime" size=6 disabled>
			minutes</td>
		</tr>
		<tr>
			<td colspan=2>Idle time<br></td>
			<td><input type=text name="idleTime_zelf" size=6 disabled> minutes</td>
			<td><input type=text name="idleTime" size=6 disabled>
			minutes</td>
		</tr>
		<tr>
			<td colspan=2>Tardiness<br></td>
			<td><input type=text name="tardiness_zelf" size=6 disabled> minutes</td>
			<td><input type=text name="tardiness" size=6 disabled>
			minutes</td>
		</tr>
		<tr>
			<td colspan=2>Fraction of excess<br></td>
			<td><input type=text name="fracExcess_zelf" size=6 disabled> %</td>
			<td><input type=text name="fracExcess" size=6 disabled> %</td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td colspan=2>Makespan<br></td>
			<td><input type=text name="makeSpan_zelf" size=6 disabled> minutes</td>
			<td><input type=text name="makeSpan" size=6 disabled> minutes</td>
		</tr>
		<tr>
			<td colspan=2>Lateness<br></td>
			<td><input type=text name="lateness_zelf" size=6 disabled> minutes</td>
			<td><input type=text name="lateness" size=6 disabled> minutes</td>
		</tr>
		<tr>
			<td><br></td>
		</tr>
		<tr>
			<td colspan=2>Objective Value<br></td>
			<td><input type=text name="objVal_zelf" size=6 disabled></td>
			<td><input type=text name="objVal" size=6 disabled>
			</td>
		</tr>
		</table></FIELDSET>
		</tr>
		
		</table>
	<br>
		<TABLE WIDTH=100%>
		<TR>
			<TD WIDTH=20% ALIGN=left>
				<A HREF="disclaimer.html">disclaimer</A>
			</TD>
			<TD WIDTH=50% ALIGN=center>
&copy; 2007-2018
Guido Kaandorp,
<A HREF="http://www.few.vu.nl/~koole">Ger Koole</A> and Jerry Timmer (thanks to Dennis Roubos)
			</TD>
			<TD WIDTH=30% ALIGN=right>		
				 <!--<A HREF="help.html">help</A>
				 | --><A HREF="mailto: koole@few.vu.nl">contact</A>
			</TD>
		</tr>
		</TABLE>
		</form>
		</center>

	</body>

</html>





